import React from 'react';
import './App.css';
import NavBar from "./component/nav-bar/NavBar";
import {BrowserRouter as Router, Route, Routes} from 'react-router-dom';
import AuthForm from "./component/connection/auth/AuthForm";
import RegisterForm from "./component/connection/register/RegisterForm";
import OfferList from "./component/offer/offer-list/OfferList";
import OfferAdd from "./component/offer/offer-add/OfferAdd";
import Profile from "./component/connection/profile/Profile";

function App() {
    return (
        <Router>
            <div className="App">
                <NavBar/>
                <Routes>
                    <Route path="/my-offers" element={<OfferList/>}/>
                    <Route path="/" element={<AuthForm/>}/>
                    <Route path="/register" element={<RegisterForm/>}/>
                    <Route path="/add-offer" element={<OfferAdd/>}/>
                    <Route path="/profile" element={<Profile/>}/>
                </Routes>
            </div>
        </Router>
    );
}

export default App;
