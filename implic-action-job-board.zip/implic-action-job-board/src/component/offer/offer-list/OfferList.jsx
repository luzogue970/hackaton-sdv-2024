import React, {Component} from 'react';
import './OfferList.css';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {
    faBuilding,
    faCalendarAlt,
    faClipboard,
    faFileContract,
    faInfoCircle,
    faMapMarkerAlt,
    faMoneyBillWave,
    faTools
} from '@fortawesome/free-solid-svg-icons';

class OfferList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            offers: [],
            userData: null,
        };
    }

    componentDidMount() {
        const userData = JSON.parse(localStorage.getItem('user'));
        const entrepriseId = userData.entreprise;

        this.setState({userData});

        fetch(`http://localhost:3000/api/offres-emploi/entreprise/${entrepriseId}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${process.env.REACT_APP_BEARER_TOKEN}`
            }
        })
            .then((response) => response.json())
            .then((data) => {
                if (Array.isArray(data)) {
                    this.setState({offers: data});
                } else {
                    this.setState({offers: []});
                }
            })
            .catch((error) => {
                console.error('Error:', error);
                this.setState({offers: []});
            });
    }

    formatDate(dateString) {
        const options = {year: 'numeric', month: 'long', day: 'numeric'};
        return new Date(dateString).toLocaleDateString('fr-FR', options);
    }

    render() {
        const {offers, userData} = this.state;

        return (
            <div className="offer-list-container">
                {offers.length === 0 ? (
                    <div className="no-offers-message">
                        Aucune offre d’emploi trouvée pour cette entreprise.
                    </div>
                ) : (
                    offers.map((offer) => (
                        <div className="offer-card" key={offer._id}>
                            <div className="offer-header">
                                <h2 className="offer-title">{offer.titre}</h2>
                                <p className="offer-company">
                                    <FontAwesomeIcon icon={faBuilding}/> {userData ? userData.entrepriseData.nom : ''}
                                </p>
                            </div>
                            <div className="offer-body">
                                <div className="offer-column">
                                    <p><FontAwesomeIcon icon={faMapMarkerAlt}/> {offer.localisation}</p>
                                    <p><FontAwesomeIcon icon={faClipboard}/> {offer.description}</p>
                                </div>
                                <div className="offer-column">
                                    <p><FontAwesomeIcon icon={faTools}/>
                                        <strong>Compétences:</strong> {offer.competences_requises}</p>
                                    <p><FontAwesomeIcon icon={faFileContract}/> <strong>Type de
                                        contrat:</strong> {offer.type_contrat}</p>
                                    <p><FontAwesomeIcon icon={faInfoCircle}/> <strong>Statut:</strong> {offer.statut}
                                    </p>
                                </div>
                                <div className="offer-column">
                                    <p><FontAwesomeIcon icon={faMoneyBillWave}/>
                                        <strong>Salaire:</strong> {offer.salaire}</p>
                                    <p><FontAwesomeIcon icon={faCalendarAlt}/> <strong>Date de
                                        début:</strong> {this.formatDate(offer.date_debut)}</p>
                                    <p><FontAwesomeIcon icon={faCalendarAlt}/> <strong>Date de
                                        fin:</strong> {this.formatDate(offer.date_fin)}</p>
                                </div>
                            </div>
                        </div>
                    ))
                )}
            </div>
        );
    }
}

export default OfferList;
