import React, {Component} from 'react';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faFileExport, faSpinner} from '@fortawesome/free-solid-svg-icons';
import './DragAndDrop.css';

class DragAndDrop extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isDragging: false,
            file: null,
            isLoading: false,
        };
        this.fileInputRef = React.createRef();
    }

    handleDragOver = (event) => {
        event.preventDefault();
        event.stopPropagation();
        this.setState({isDragging: true});
    };

    handleDragEnter = (event) => {
        event.preventDefault();
        event.stopPropagation();
        this.setState({isDragging: true});
    };

    handleDragLeave = (event) => {
        event.preventDefault();
        event.stopPropagation();
        this.setState({isDragging: false});
    };

    handleDrop = (event) => {
        event.preventDefault();
        event.stopPropagation();
        this.setState({isDragging: false});

        const files = event.dataTransfer.files;
        if (files.length > 0) {
            const file = files[0];
            if (this.validateFile(file)) {
                this.setState({file, isLoading: true}, () => this.uploadFile(file));
            } else {
                alert('Seuls les fichiers Word et PDF sont acceptés.');
            }
        }
    };

    handleClick = () => {
        this.fileInputRef.current.click();
    };

    handleFileChange = (event) => {
        const files = event.target.files;
        if (files.length > 0) {
            const file = files[0];
            if (this.validateFile(file)) {
                this.setState({file, isLoading: true}, () => this.uploadFile(file));
            } else {
                alert('Seuls les fichiers Word et PDF sont acceptés.');
            }
        }
    };

    validateFile = (file) => {
        const validTypes = [
            'application/pdf',
        ];
        return validTypes.includes(file.type);
    };

    uploadFile = (file) => {
        const formData = new FormData();
        formData.append('fichier', file);

        fetch('http://localhost:3000/api/offres-emploi/extract-data', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${process.env.REACT_APP_BEARER_TOKEN}`
            },
            body: formData,
        })
            .then((response) => response.json())
            .then((data) => {
                this.setState({isLoading: false});
                this.props.onFileUpload(data); // Lever l'état au parent
            })
            .catch((error) => {
                this.setState({isLoading: false});
                console.error('Error:', error);
            });
    };

    render() {
        const {isDragging, isLoading} = this.state;
        return (
            <div>
                <div
                    className={`offer-by-document ${isDragging ? 'dragging' : ''}`}
                    onDragOver={this.handleDragOver}
                    onDragEnter={this.handleDragEnter}
                    onDragLeave={this.handleDragLeave}
                    onDrop={this.handleDrop}
                    onClick={this.handleClick}
                >
                    <h1 className="title">déposer mon offre</h1>
                    {isLoading ? (
                        <FontAwesomeIcon icon={faSpinner} className="loading-icon" spin/>
                    ) : (
                        <FontAwesomeIcon icon={faFileExport} className="add-document-icon"/>
                    )}
                </div>
                <input
                    type="file"
                    ref={this.fileInputRef}
                    style={{display: 'none'}}
                    onChange={this.handleFileChange}
                    accept=".pdf,.doc,.docx"
                />
            </div>
        );
    }
}

export default DragAndDrop;
