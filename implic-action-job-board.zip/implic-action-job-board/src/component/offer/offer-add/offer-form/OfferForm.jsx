import React, {useEffect, useState} from 'react';
import {useNavigate} from 'react-router-dom';
import "./OfferForm.css";

const OfferForm = ({uploadedData}) => {
    const [formData, setFormData] = useState({
        titre: '',
        description: '',
        competences_requises: '',
        localisation: '',
        type_contrat: '',
        salaire: '',
        date_debut: '',
    });
    const [fichier, setFichier] = useState(null);
    const [entrepriseId, setEntrepriseId] = useState(null);
    const [message, setMessage] = useState('');

    const navigate = useNavigate();

    useEffect(() => {
        const userData = JSON.parse(localStorage.getItem('user'));
        if (userData && userData.entreprise) {
            setEntrepriseId(userData.entreprise);
        }
    }, []);

    useEffect(() => {
        if (uploadedData) {
            const {
                titre,
                description,
                competences_requises,
                localisation,
                type_contrat,
                salaire,
                date_debut
            } = uploadedData;
            setFormData({
                titre: titre || '',
                description: description || '',
                competences_requises: competences_requises || '',
                localisation: localisation || '',
                type_contrat: type_contrat || '',
                salaire: salaire ? salaire.toString() : '0',
                date_debut: date_debut ? date_debut.split('T')[0] : '',
            });
        }
    }, [uploadedData]);

    const handleChange = (e) => {
        const {name, value} = e.target;
        setFormData((prevFormData) => ({
            ...prevFormData,
            [name]: value,
        }));
    };

    const handleFileChange = (e) => {
        setFichier(e.target.files[0]);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const formDataToSend = new FormData();
        for (const key in formData) {
            formDataToSend.append(key, formData[key]);
        }
        if (fichier) {
            formDataToSend.append('fichier', fichier);
        }
        if (entrepriseId) {
            formDataToSend.append('entreprise_id', entrepriseId);
        }

        try {
            const response = await fetch('http://localhost:3000/api/offres-emploi', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${process.env.REACT_APP_BEARER_TOKEN}`
                },
                body: formDataToSend,
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const data = await response.json();
            console.log('Success:', data);
            setMessage('Offre bien ajoutée ! Redirection...');
            console.log("message mis redirection en cour")
            setTimeout(() => {
                navigate('/my-offers');
            }, 2000);
        } catch (error) {
            console.error('Error:', error);
            setMessage('Échec de l\'ajout de l\'offre, veuillez réessayer.');
        }
    };

    return (
        <form onSubmit={handleSubmit} className="offer-by-form">
            <label>
                Titre:
                <input type="text" name="titre" value={formData.titre} onChange={handleChange}/>
            </label>
            <label>
                Localisation:
                <input type="text" name="localisation" value={formData.localisation} onChange={handleChange}/>
            </label>
            <label>
                Description:
                <textarea name="description" value={formData.description} onChange={handleChange}/>
            </label>
            <label>
                Compétences requises:
                <textarea name="competences_requises" value={formData.competences_requises} onChange={handleChange}/>
            </label>
            <label>
                Type de contrat:
                <input type="text" name="type_contrat" value={formData.type_contrat} onChange={handleChange}/>
            </label>
            <label>
                Salaire annuel:
                <input type="text" name="salaire" value={formData.salaire + "K"} onChange={handleChange}/>
            </label>
            <label>
                Date de début:
                <input type="date" name="date_debut" value={formData.date_debut} onChange={handleChange}/>
            </label>
            <label className="file-label">
                Pièce jointe:
                <input type="file" accept="application/pdf" onChange={handleFileChange}/>
            </label>
            <button type="submit">Soumettre</button>
            {message && <p>{message}</p>}
        </form>
    );
};

export default OfferForm;
