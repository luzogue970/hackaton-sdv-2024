import React, {Component} from 'react';
import './OfferAdd.css';
import OfferForm from './offer-form/OfferForm';
import DragAndDrop from './drag-and-drop/DargAndDrop';

class OfferAdd extends Component {
    constructor(props) {
        super(props);
        this.state = {
            uploadedData: null,
        };
    }

    handleFileUpload = (data) => {
        this.setState({uploadedData: data});
    };

    render() {
        return (
            <div className="offerAdd section">
                <h1 className="section-title">Ajouter une offre</h1>
                <div className="content">
                    <div className="left-section">
                        <OfferForm uploadedData={this.state.uploadedData}/>
                    </div>
                    <div className="right-section">
                        <DragAndDrop onFileUpload={this.handleFileUpload}/>
                    </div>
                </div>
            </div>
        );
    }
}

export default OfferAdd;
