import React, {Component} from 'react';
import './NavBar.css';
import {Link, useNavigate} from 'react-router-dom';
import logo from "../../asset/implic-action.png";

class NavBar extends Component {
    render() {
        const user = JSON.parse(localStorage.getItem('user'));
        const navigate = this.props.navigate;

        const handleLogout = () => {
            localStorage.removeItem('user');
            navigate('/');
        };

        return (
            <nav className="navbar">
                <div className="navBrand">
                    <img src={logo} alt="Logo" style={{height: '11vh'}}/>
                </div>
                <ul className="navItems">
                    <li className="navItem">
                        {!user && <Link to="/" className="navItem">Connexion</Link>}
                        {!user && <Link to="/register" className="navItem">Inscription</Link>}
                        {user && <Link to="/profile" className="navItem">Profile</Link>}
                        {user && <Link to="/add-offer" className="navItem">Ajouter une offre</Link>}
                        {user && <Link to="/my-offers" className="navItem">Mes offres</Link>}
                        {user && <button onClick={handleLogout} className="logout-button">Déconnexion</button>}
                    </li>
                </ul>
            </nav>
        );
    }
}

const NavBarWithNavigate = (props) => {
    const navigate = useNavigate();
    return <NavBar {...props} navigate={navigate}/>;
};

export default NavBarWithNavigate;
