import React, {useState} from 'react';
import './AuthForm.css';
import {useNavigate} from 'react-router-dom';

const AuthForm = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');

    const navigate = useNavigate();

    async function getEntrepriseData(entrepriseId) {
        const entrepriseResponse = await fetch('http://localhost:3000/api/entreprises/' + entrepriseId, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${process.env.REACT_APP_BEARER_TOKEN}`,
            }
        });

        if (!entrepriseResponse.ok) {
            throw new Error('Network response was not ok');
        }

        return await entrepriseResponse.json();
    }

    const handleSubmit = async (e) => {
        e.preventDefault();

        const userData = {
            email: username,
            mot_de_passe: password,
        };

        try {
            const response = await fetch('http://localhost:3000/api/utilisateurs/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${process.env.REACT_APP_BEARER_TOKEN}`,
                },
                body: JSON.stringify(userData),
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const data = await response.json();
            let entreprise;

            if (data && data.entreprise) {
                entreprise = await getEntrepriseData(data.entreprise);
                data.entrepriseData = entreprise;
            } else {
                console.error('La réponse JSON ne contient pas de propriété entreprise');
            }

            console.log(data);
            localStorage.setItem('user', JSON.stringify(data));
            setMessage('Connexion réussie ! Redirection...');
            setTimeout(() => {
                navigate('/add-offer');
            }, 2000);
        } catch (error) {
            console.error('Error:', error);
            setMessage('Échec de la connexion, veuillez réessayer.');
        }
    };

    return (
        <div className="auth-container">
            <form className="auth-form" onSubmit={handleSubmit}>
                <div className="input-container">
                    <label htmlFor="username">email</label>
                    <input
                        type="text"
                        id="username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        className="username-input"
                    />
                </div>
                <div className="input-container">
                    <label htmlFor="password">Mdp</label>
                    <input
                        type="password"
                        id="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="password-input"
                    />
                </div>
                <button type="submit" className="submit-button">Connexion</button>
                {message && <p>{message}</p>}
            </form>
        </div>
    );
};

export default AuthForm;
