import React, {useEffect, useState} from 'react';
import './Profile.css';

const Profile = () => {
    const [user, setUser] = useState(null);

    useEffect(() => {
        const userData = localStorage.getItem('user');
        if (userData) {
            setUser(JSON.parse(userData));
        }
    }, []);

    if (!user) {
        return <p>Loading...</p>;
    }

    return (
        <div className="profile-container">
            <h2>Mon Profil</h2>
            <p>Email: {user.email}</p>
            <p>Nom: {user.nom}</p>
            {user.entrepriseData && (
                <>
                    <h3>Informations sur l'entreprise</h3>
                    <p>Nom de l'entreprise: {user.entrepriseData.nom}</p>
                    <p>Email de l'entreprise: {user.entrepriseData.contact.email}</p>
                </>
            )}
        </div>
    );
};

export default Profile;
