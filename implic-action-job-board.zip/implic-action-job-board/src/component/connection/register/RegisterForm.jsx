import React, {useState} from 'react';
import './RegisterForm.css';
import {useNavigate} from "react-router-dom";

const RegisterForm = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [email, setEmail] = useState('');
    const [name, setName] = useState('');
    const [sector, setSector] = useState('');
    const [telephone, setTelephone] = useState('');
    const [message, setMessage] = useState('');

    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (password !== confirmPassword) {
            setMessage('Les mots de passe ne correspondent pas.');
            return;
        }

        const userData = {
            nom: username,
            mot_de_passe: password,
            email: email,
            role: "entreprise",
            entreprise: ""
        };

        const entrepriseData = {
            nom: name,
            secteur: sector,
            contact: {
                email: email,
                telephone: telephone
            }
        };

        try {
            const entrepriseResponse = await fetch('http://localhost:3000/api/entreprises', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${process.env.REACT_APP_BEARER_TOKEN}`,
                },
                body: JSON.stringify(entrepriseData),
            });

            if (!entrepriseResponse.ok) {
                throw new Error('Network response was not ok');
            }

            const entreprise = await entrepriseResponse.json();
            console.log(entreprise)
            if (entreprise && entreprise._id) {
                userData.entreprise = entreprise._id;
            } else {
                console.error('La réponse JSON ne contient pas de propriété id');
            }
            console.log(userData)

        } catch (error) {
            console.error('Error:', error);
            setMessage('Échec de l’inscription, veuillez réessayer.');
        }

        const userResponse = await fetch('http://localhost:3000/api/utilisateurs', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${process.env.REACT_APP_BEARER_TOKEN}`,
            },
            body: JSON.stringify(userData),
        });

        if (!userResponse.ok) {
            throw new Error('Network response was not ok');
        }

        const user = await userResponse.json();
        console.log(user)

        setMessage('Inscription réussie ! Redirection...');
        setTimeout(() => {
            navigate('/');
        }, 2000);
    };

    return (
        <div className="register-container">
            <form className="register-form" onSubmit={handleSubmit}>
                <div className="input-container">
                    <label htmlFor="username">Utilisateur</label>
                    <input
                        type="text"
                        id="username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        className="username-input"
                    />
                </div>
                <div className="input-container">
                    <label htmlFor="password">Mdp</label>
                    <input
                        type="password"
                        id="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="password-input"
                    />
                </div>
                <div className="input-container">
                    <label htmlFor="confirmPassword">Confirmation Mdp</label>
                    <input
                        type="password"
                        id="confirmPassword"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className="confirm-password-input"
                    />
                </div>
                <div className="input-container">
                    <label htmlFor="email">Mail</label>
                    <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="email-input"
                    />
                </div>
                <div className="input-container">
                    <label htmlFor="name">Nom de l'entreprise</label>
                    <input
                        type="text"
                        id="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="name-input"
                    />
                </div>
                <div className="input-container">
                    <label htmlFor="sector">Secteur</label>
                    <input
                        type="text"
                        id="sector"
                        value={sector}
                        onChange={(e) => setSector(e.target.value)}
                        className="sector-input"
                    />
                </div>
                <div className="input-container">
                    <label htmlFor="telephone">Téléphone</label>
                    <input
                        type="text"
                        id="telephone"
                        value={telephone}
                        onChange={(e) => setTelephone(e.target.value)}
                        className="telephone-input"
                    />
                </div>
                <button type="submit" className="submit-button">Valider</button>
                {message && <p>{message}</p>}
            </form>
        </div>
    );
};

export default RegisterForm;
