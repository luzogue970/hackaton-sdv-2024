# Implic Action Job Board

## Vue d'ensemble

Le Job Board d'Implic Action est une application web conçue pour simplifier le processus de téléchargement et de
publication des offres d'emploi pour les entreprises.
Cette application frontend a été développée lors d'un hackathon.
Elle fournit une interface permettant de glisser-déposer des PDF de candidatures pour publier rapidement des offres
d'emploi sur le job board d'Implic Action.

## Structure du Projet

La structure du projet est la suivante :

```
implic-action-job-board/
├── public/                   
├── src/                       # Code source
│   ├── asset/                 # Assets statiques
│   ├── component/             # Composants React
│   │   ├── connection/        # Composants liés à l'authentification et à l'inscription des utilisateurs
│   │   │   ├── auth/          # Composants d'authentification
│   │   │   │   ├── AuthForm.css
│   │   │   │   └── AuthForm.jsx
│   │   │   ├── profile/       # Composants de profil utilisateur
│   │   │   │   ├── Profile.css
│   │   │   │   └── Profile.jsx
│   │   │   ├── register/      # Composants d'inscription des utilisateurs
│   │   │       ├── RegisterForm.css
│   │   │       └── RegisterForm.jsx
│   │   ├── nav-bar/           # Composants de la barre de navigation
│   │   │   ├── NavBar.css
│   │   │   └── NavBar.jsx
│   │   ├── offer/             # Composants des offres d'emploi
│   │       ├── offer-add/     # Composants pour ajouter des offres d'emploi
│   │       │   ├── drag-and-drop/
│   │       │   │   ├── DragAndDrop.css
│   │       │   │   └── DragAndDrop.jsx
│   │       │   ├── offer-form/
│   │       │       ├── OfferForm.css
│   │       │       └── OfferForm.jsx
│   │       ├── OfferAdd.css
│   │       ├── OfferAdd.jsx
│   │       ├── offer-list/    # Composants pour lister les offres d'emploi
│   │           ├── OfferList.css
│   │           └── OfferList.jsx
│   ├── App.css                # Styles globaux
│   ├── App.js                 # Composant principal de l'application
│   ├── index.css              # Styles de l'index
│   ├── index.js               # Point d'entrée de l'application
│   ├── reportWebVitals.js     
│   └── setupTests.js          
├── .env                       # Variables d'environnement
├── .gitignore                 
```

## Composants Clés

### Authentification et Inscription

- **AuthForm.jsx**: Gère la connexion des utilisateurs.
- **RegisterForm.jsx**: Gère l'inscription des utilisateurs.
- **Profile.jsx**: Affiche les informations du profil utilisateur.

### Navigation

- **NavBar.jsx**: Fournit la navigation entre les différentes sections de l'application.

### Offres d'emploi

- **OfferAdd.jsx**: Composant principal pour ajouter des offres d'emploi.
    - **DragAndDrop.jsx**: Permet de glisser-déposer des PDF de candidatures.
    - **OfferForm.jsx**: Formulaire pour saisir les détails de l'offre d'emploi.
- **OfferList.jsx**: Affiche une liste des offres d'emploi publiées.

## Installation et Configuration

1. **Cloner le Référentiel**:
   ```sh
   git clone https://github.com/your-repo/implic-action-job-board.git
   cd implic-action-job-board
   ```

2. **Installer les Dépendances**:
   ```sh
   npm install
   ```

3. **Configurer les Variables d'Environnement**:
   Créez un fichier `.env` dans le répertoire racine et ajoutez les variables d'environnement nécessaires.

4. **Lancer l'Application**:
   ```sh
   npm start
   ```

## Technologies Utilisées

- **React.js**: Bibliothèque JavaScript pour construire des interfaces utilisateur.
- **CSS**: Pour le style des composants.
- **Node.js**: Runtime backend pour gérer les opérations côté serveur.
- **Express.js**: Framework web pour Node.js .
- **MongoDB**: Base de données pour stocker les offres d'emploi, les informations des utilisateurs et entreprises.

## Fonctionnalités

- **Authentification des Utilisateurs**: Connexion et inscription sécurisées.
- **Gestion du Profil**: Affichage des détails du profil utilisateur.
- **Gestion des Offres d'Emploi**: Ajout et listing des offres d'emploi.
- **Glisser-Déposer**: Téléchargement facile des PDF de candidatures pour créer des offres d'emploi avec mistral AI.
